config = {
        'user':'teste',
        'password':'Abc.123456',
        'host':'gupyteste.mysql.database.azure.com',
        'port':'3306',
        'database':'casegupy'
}